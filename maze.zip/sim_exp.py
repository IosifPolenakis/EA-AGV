import random
from collections import deque

# Constants
grid_width = 30
grid_height = 20
grid_size = 20
battery_energy = 1000
battery_low = 2

# Maze generation
def generate_maze(width, height):
    maze = [[1 for _ in range(width)] for _ in range(height)]
    stack = [(1, 1)]
    maze[1][1] = 0

    def get_neighbors(x, y):
        directions = [(x + 2, y), (x - 2, y), (x, y + 2), (x, y - 2)]
        return [(nx, ny) for nx, ny in directions
                if 1 <= nx < width - 1 and 1 <= ny < height - 1 and maze[ny][nx] == 1]

    while stack:
        x, y = stack[-1]
        neighbors = get_neighbors(x, y)
        if neighbors:
            nx, ny = random.choice(neighbors)
            maze[ny][nx] = 0
            maze[(ny + y) // 2][(nx + x) // 2] = 0
            stack.append((nx, ny))
        else:
            stack.pop()
    return maze

# AGV class
class AGV:
    def __init__(self, maze, start):
        self.maze = maze
        self.start = start
        self.x, self.y = start
        self.visited = set([start])
        self.energy = battery_energy
        self.backtracked = False
        self.path = []
        self.full_backtrack_energy = None

    def get_neighbors(self, x, y):
        for dx, dy in [(0, -1), (1, 0), (0, 1), (-1, 0)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < len(self.maze[0]) and 0 <= ny < len(self.maze) and self.maze[ny][nx] == 0:
                yield (nx, ny)

    def consume_energy(self, direction_change):
        base = 1
        sonar = 2 if direction_change else 0
        servo = 3
        self.energy -= (base + sonar + servo)

    def find_path(self, start, goal):
        queue = deque([start])
        came_from = {start: None}
        while queue:
            current = queue.popleft()
            if current == goal:
                break
            for neighbor in self.get_neighbors(*current):
                if neighbor not in came_from:
                    came_from[neighbor] = current
                    queue.append(neighbor)
        path = []
        node = goal
        while node is not None:
            path.append(node)
            node = came_from[node]
        return list(reversed(path))
    
    def get_next(self, frontier, alg):
        if alg == 'bfs':
            return frontier.popleft()
        elif alg == 'dfs':
            return frontier.pop()
        elif alg == 'astar':
            best = min(frontier, key=lambda x: abs(x[0] - self.start[0]) + abs(x[1] - self.start[1]))
            frontier.remove(best)
            return best
        else:
            raise ValueError(f"Unknown algorithm: {alg}")
        
    def explore(self, alg):
        frontier = deque()
        self.visited = {self.start}
        for n in self.get_neighbors(*self.start):
            frontier.append(n)
        last = self.start

        while frontier and self.energy > 0:
            current = self.get_next(frontier, alg)
            self.consume_energy(current != last)
            if current not in self.visited:
                self.visited.add(current)
                last = current
                for n in self.get_neighbors(*current):
                    if n not in self.visited and n not in frontier:
                        frontier.append(n)
            if self.energy < battery_energy / battery_low:
                break


        # Backtrack
        backtrack_path = self.find_path(last, self.start)
        for i in range(1, len(backtrack_path)):
            self.consume_energy(backtrack_path[i-1] != backtrack_path[i])
        self.full_backtrack_energy = self.energy

# Simulation
algorithms = ['bfs', 'dfs', 'astar']
battery_levels = {alg: [] for alg in algorithms}
coverage_percent = {alg: [] for alg in algorithms}

for maze_id in range(10):
    maze = generate_maze(grid_width, grid_height)
    white_cells = sum(row.count(0) for row in maze)
    white_positions = [(x, y) for y in range(grid_height) for x in range(grid_width) if maze[y][x] == 0]
    starts = random.sample(white_positions, 10)

    for start in starts:
        for alg in algorithms:
            agv = AGV(maze, start)
            agv.explore(alg)
            percent = len(agv.visited) / white_cells * 100
            battery_levels[alg].append(agv.full_backtrack_energy)
            coverage_percent[alg].append(percent)
            print(f"Maze {maze_id+1}, Start {start}, Algo {alg}: Coverage {percent:.2f}%, Battery left {agv.full_backtrack_energy}")

print("\n--- Averages ---")
for alg in algorithms:
    avg_battery = sum(battery_levels[alg]) / len(battery_levels[alg])
    avg_coverage = sum(coverage_percent[alg]) / len(coverage_percent[alg])
    print(f"{alg.upper()}: Avg Battery Left = {avg_battery:.2f}, Avg Coverage = {avg_coverage:.2f}%")