import pygame
import sys
import random
import os
from collections import deque
from datetime import datetime

# Constants
grid_size = 20
grid_width = 30
grid_height = 20
info_bar_height = 60
battery_energy=1000
battery_low=2

screen_width = grid_width * grid_size
screen_height = grid_height * grid_size + info_bar_height
fps = 30

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
PINK = (255, 105, 180)
YELLOW = (255, 255, 0)

# Maze generation
def generate_maze(width, height):
    maze = [[1 for _ in range(width)] for _ in range(height)]
    stack = [(1, 1)]
    maze[1][1] = 0

    def get_neighbors(x, y):
        directions = [(x + 2, y), (x - 2, y), (x, y + 2), (x, y - 2)]
        return [(nx, ny) for nx, ny in directions
                if 1 <= nx < width - 1 and 1 <= ny < height - 1 and maze[ny][nx] == 1]

    while stack:
        x, y = stack[-1]
        neighbors = get_neighbors(x, y)
        if neighbors:
            nx, ny = random.choice(neighbors)
            maze[ny][nx] = 0
            maze[(ny + y) // 2][(nx + x) // 2] = 0
            stack.append((nx, ny))
        else:
            stack.pop()
    return maze

# AGV Class
class AGV:
    def __init__(self, maze):
        self.maze = maze
        self.width = len(maze[0])
        self.height = len(maze)
        self.x, self.y = -1, -1
        self.start = None
        self.visited = set()
        self.frontier = deque()
        self.energy = battery_energy
        self.mode = None
        self.move_path = deque()
        self.pink_cells = set()
        self.blue_cells = set()
        self.green_cells = set()
        self.came_from = {}
        self.logging = []
        self.full_backtrack_logged = False
        self.white_cell_count = sum(row.count(0) for row in self.maze)
        self.exploration_complete = False
        self.full_backtrack_path = []
        self.last_direction = None

    def set_start(self, x, y):
        if self.maze[y][x] == 0:
            self.x, self.y = x, y
            self.start = (x, y)
            self.visited = {self.start}
            return True
        return False

    def get_neighbors(self, x, y):
        for dx, dy in [(0, -1), (1, 0), (0, 1), (-1, 0)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height and self.maze[ny][nx] == 0:
                yield (nx, ny)

    def bfs(self):
        self.frontier = deque([self.start])
        self.mode = 'bfs'
        self.came_from = {}
        self.visited = {self.start}

    def dfs(self):
        self.frontier = deque([self.start])
        self.mode = 'dfs'
        self.came_from = {}
        self.visited = {self.start}

    def astar(self):
        self.frontier = deque([self.start])
        self.mode = 'astar'
        self.came_from = {}
        self.visited = {self.start}

    def heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def find_path(self, start, goal):
        queue = deque([start])
        came = {start: None}
        while queue:
            current = queue.popleft()
            if current == goal:
                break
            for neighbor in self.get_neighbors(*current):
                if neighbor not in came and neighbor in self.visited:
                    came[neighbor] = current
                    queue.append(neighbor)
        path = []
        node = goal
        while node is not None:
            path.append(node)
            node = came.get(node)
        return list(reversed(path))

    def consume_energy(self, direction):
        base_cost = 1
        sonar_cost = 0
        if self.last_direction is None or direction != self.last_direction:
            sonar_cost = 2  # sideway sonar energy cost only if direction changes
        servo_camera_cost = 3  # 3 pictures per step
        total = base_cost + sonar_cost + servo_camera_cost
        self.energy -= total
        self.last_direction = direction

    def update(self):
        if self.energy <= 0 or self.exploration_complete:
            if not self.full_backtrack_logged:
                self.save_logs()
                self.full_backtrack_logged = True
            return

        if self.move_path:
            next_cell, is_backtracking = self.move_path.popleft()
            movement = self.get_movement_direction((self.x, self.y), next_cell)
            self.x, self.y = next_cell

            if is_backtracking == "FB":
                self.green_cells.add(next_cell)
                self.full_backtrack_path.append(next_cell)
            elif is_backtracking:
                self.pink_cells.add(next_cell)
                self.blue_cells.discard(next_cell)
            else:
                self.blue_cells.add(next_cell)
                self.visited.add(next_cell)

            self.consume_energy(movement)
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            tag = "(FB)" if is_backtracking == "FB" else "(B)" if is_backtracking else "(F)"
            self.logging.append(f"{timestamp} - {movement} {tag} - {next_cell}")

            if is_backtracking == "FB" and (self.x, self.y) == self.start:
                if not self.full_backtrack_logged:
                    self.save_logs(full_backtrack_path=self.full_backtrack_path.copy())
                    self.full_backtrack_logged = True
                self.exploration_complete = True
            return

        if not self.frontier:
            if (self.x, self.y) != self.start:
                path = self.find_path((self.x, self.y), self.start)
                for pos in path[1:]:
                    self.move_path.append((pos, "FB"))
            return

        if self.energy < (battery_energy/battery_low) and not self.full_backtrack_logged:
            path = self.find_path((self.x, self.y), self.start)
            for pos in path[1:]:
                self.move_path.append((pos, "FB"))
            return

        current = None
        if self.mode == 'bfs':
            current = self.frontier.popleft()
        elif self.mode == 'dfs':
            current = self.frontier.pop()
        elif self.mode == 'astar':
            current = min(self.frontier, key=lambda x: self.heuristic(x, self.start))
            self.frontier.remove(current)

        if abs(self.x - current[0]) + abs(self.y - current[1]) > 1:
            path = self.find_path((self.x, self.y), current)
            for pos in path[1:]:
                self.move_path.append((pos, True))
            self.move_path.append((current, False))
        else:
            self.move_path.append((current, False))

        for neighbor in self.get_neighbors(*current):
            if neighbor not in self.visited and neighbor not in self.frontier:
                self.came_from[neighbor] = current
                self.visited.add(neighbor)
                self.frontier.append(neighbor)

    def get_movement_direction(self, current, next_cell):
        dx = next_cell[0] - current[0]
        dy = next_cell[1] - current[1]
        if dx == 1:
            return "EAST"
        elif dx == -1:
            return "WEST"
        elif dy == 1:
            return "SOUTH"
        elif dy == -1:
            return "NORTH"
        return "STAY"

    def save_logs(self, full_backtrack_path=None):
        folder = os.getcwd()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        agv_log_path = os.path.join(folder, "agv_log.txt")
        with open(agv_log_path, 'w') as f:
            f.write("\n".join(self.logging))

        if full_backtrack_path:
            backtrack_path_file = os.path.join(folder, f"full_backtrack_{timestamp}.txt")
            with open(backtrack_path_file, 'w') as f:
                reversed_path = full_backtrack_path[::-1]
                for i in range(len(reversed_path) - 1):
                    current = reversed_path[i]
                    next_cell = reversed_path[i + 1]
                    direction = self.get_movement_direction(current, next_cell)
                    f.write(f"{current} -> {direction} -> {next_cell}\n")
                f.write(f"{reversed_path[-1]}\n")


import random

def random_free_cells(maze, count):
    free_cells = [(x, y) for y, row in enumerate(maze) for x, cell in enumerate(row) if cell == 0]
    return random.sample(free_cells, count)

def run_single_exploration(maze, start, algo_name):
    agv = AGV(maze)
    agv.set_start(*start)

    # Initialize exploration mode
    if algo_name == 'BFS':
        agv.bfs()
    elif algo_name == 'DFS':
        agv.dfs()
    elif algo_name == 'A*':
        agv.astar()
    else:
        raise ValueError(f"Unknown algorithm: {algo_name}")

    # Run until exploration complete or out of energy
    while not agv.exploration_complete and agv.energy > 0:
        agv.update()

    coverage = (len(agv.visited) / agv.white_cell_count) * 100 if agv.white_cell_count > 0 else 0
    battery_left = agv.energy
    return coverage, battery_left

def run_experiments():
    maze_count = 10
    starts_per_maze = 10
    algorithms = ['BFS', 'DFS', 'A*']

    # Store sums for averages
    results = {algo: {'coverage': 0, 'battery': 0, 'runs': 0} for algo in algorithms}

    for i in range(maze_count):
        maze = generate_maze(grid_width, grid_height)
        start_points = random_free_cells(maze, starts_per_maze)

        for start in start_points:
            for algo in algorithms:
                coverage, battery = run_single_exploration(maze, start, algo)
                results[algo]['coverage'] += coverage
                results[algo]['battery'] += battery
                results[algo]['runs'] += 1

        print(f"Maze {i+1} done.")

    print("\n=== Average Results After All Experiments ===")
    for algo in algorithms:
        avg_cov = results[algo]['coverage'] / results[algo]['runs']
        avg_bat = results[algo]['battery'] / results[algo]['runs']
        print(f"{algo}: Average Coverage = {avg_cov:.2f}%, Average Battery Left = {avg_bat:.2f}")

# To run batch experiments, just call:
run_experiments()


# Pygame setup
pygame.init()
pygame.font.init()
font = pygame.font.SysFont(None, 24)
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("AGV Maze Traversal with Energy Display")
clock = pygame.time.Clock()

maze = generate_maze(grid_width, grid_height)
robot = AGV(maze)

selected_algo = [None]

class RadioButton:
    def __init__(self, x, y, text):
        self.rect = pygame.Rect(x, y, 60, 25)
        self.text = text
        self.selected = False

    def draw(self, surface):
        color = BLUE if self.selected else WHITE
        pygame.draw.rect(surface, color, self.rect)
        pygame.draw.rect(surface, BLACK, self.rect, 2)
        label = font.render(self.text, True, BLACK)
        surface.blit(label, (self.rect.x + 5, self.rect.y + 5))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            for rb in radio_buttons:
                rb.selected = False
            self.selected = True
            selected_algo[0] = self.text

class Button:
    def __init__(self, x, y, w, h, text, callback):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.callback = callback

    def draw(self, surface):
        pygame.draw.rect(surface, YELLOW, self.rect)
        pygame.draw.rect(surface, BLACK, self.rect, 2)
        label = font.render(self.text, True, BLACK)
        surface.blit(label, (self.rect.x + 5, self.rect.y + 5))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            self.callback()

radio_buttons = [
    RadioButton(10, screen_height - 20, "BFS"),
    RadioButton(80, screen_height - 20, "DFS"),
    RadioButton(150, screen_height - 20, "A*"),
]

def reset_simulation():
    global maze, robot, selecting_start
    maze = generate_maze(grid_width, grid_height)
    robot = AGV(maze)
    selecting_start = True
    for rb in radio_buttons:
        rb.selected = False
    selected_algo[0] = None

def restart_same_maze():
    global robot, selecting_start
    robot = AGV(maze)
    selecting_start = True
    for rb in radio_buttons:
        rb.selected = False
    selected_algo[0] = None

def start_exploration():
    if selected_algo[0] == "BFS":
        robot.bfs()
    elif selected_algo[0] == "DFS":
        robot.dfs()
    elif selected_algo[0] == "A*":
        robot.astar()

start_button = Button(220, screen_height - 20, 60, 30, "Start", start_exploration)
reset_button = Button(290, screen_height - 20, 60, 30, "Reset", reset_simulation)
restart_button = Button(360, screen_height - 20, 100, 30, "Restart", restart_same_maze)

running = True
selecting_start = True

while running:
    clock.tick(fps)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and selecting_start:
            mx, my = pygame.mouse.get_pos()
            gx, gy = mx // grid_size, my // grid_size
            if gy < grid_height and robot.set_start(gx, gy):
                selecting_start = False
        for rb in radio_buttons:
            rb.handle_event(event)
        start_button.handle_event(event)
        reset_button.handle_event(event)
        restart_button.handle_event(event)

    robot.update()

    screen.fill(WHITE)
    for y in range(grid_height):
        for x in range(grid_width):
            rect = pygame.Rect(x * grid_size, y * grid_size, grid_size, grid_size)
            color = BLACK if maze[y][x] == 1 else WHITE
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, GRAY, rect, 1)

    for (px, py) in robot.blue_cells:
        pygame.draw.rect(screen, BLUE, (px * grid_size, py * grid_size, grid_size, grid_size))
    for (px, py) in robot.pink_cells:
        pygame.draw.rect(screen, PINK, (px * grid_size, py * grid_size, grid_size, grid_size))
    for (px, py) in robot.green_cells:
        pygame.draw.rect(screen, GREEN, (px * grid_size, py * grid_size, grid_size, grid_size))

    if robot.x >= 0 and robot.y >= 0:
        pygame.draw.rect(screen, RED, (robot.x * grid_size, robot.y * grid_size, grid_size, grid_size))

    pygame.draw.rect(screen, GRAY, (0, screen_height - info_bar_height, screen_width, info_bar_height))

    energy_ratio = robot.energy / 500
    pygame.draw.rect(screen, RED, (10, screen_height - 40, 200, 20))
    pygame.draw.rect(screen, GREEN, (10, screen_height - 40, 200 * energy_ratio, 20))
    energy_label = font.render(f"Energy: {robot.energy}/1000", True, BLACK)
    screen.blit(energy_label, (220, screen_height - 40))

    visited_percent = int((len(robot.visited) / robot.white_cell_count) * 100) if robot.white_cell_count else 0
    visited_label = font.render(f"Visited: {visited_percent}%", True, BLACK)
    screen.blit(visited_label, (10, screen_height - 60))

    for rb in radio_buttons:
        rb.draw(screen)
    start_button.draw(screen)
    reset_button.draw(screen)
    restart_button.draw(screen)

    pygame.display.flip()

pygame.quit()
sys.exit()
